package kr.ac.propertiestest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Direct4_2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_direct42)
    }
}